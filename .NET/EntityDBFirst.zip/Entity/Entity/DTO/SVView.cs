﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entity.DTO
{
    public class SVView
    {
        public string MSSV { get; set; }
        public string NameSV { get; set; }
        public string NameLop { get; set; }
    }
}
